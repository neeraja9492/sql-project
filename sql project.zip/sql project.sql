show databases;
use demo;
show tables;
select * from person;
insert into person values(5,"joe",24),(6,"rani",23);

create database bank;
use bank;

  CREATE TABLE accountmaster (
  accno int NOT NULL AUTO_INCREMENT,
  name varchar(40) NOT NULL,
  address varchar(60) NOT NULL,
  date date NOT NULL,
  pan char(10) NOT NULL,
  phone varchar(20) DEFAULT NULL,
  email varchar(50) DEFAULT NULL,
  balance decimal(10,2) NOT NULL,
  PRIMARY KEY (accno)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
use bank;
show tables;
insert into accountmaster values(1002,"neeraja","banglore","2025-01-20","kvg765",9876543,"neeraja@gmail.com",15000.00);


  CREATE TABLE transaction (
  tid int NOT NULL AUTO_INCREMENT,
  accno int NOT NULL,
  date date NOT NULL,
  type varchar(20) NOT NULL,
  amount decimal(10,2) NOT NULL,
  balance decimal(10,2) NOT NULL,
  PRIMARY KEY (tid),
  KEY accno (accno),
  CONSTRAINT transaction_ibfk_1 FOREIGN KEY (accno) REFERENCES accountmaster (accno)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
show tables;
select * from bank.accountmaster;
select * from bank.transaction;
CREATE DATABASE MovieRecommendation;
USE MovieRecommendation;

-- Users Table
CREATE TABLE Users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    age INT,
    country VARCHAR(50)
);

-- Movies Table
CREATE TABLE Movies (
    movie_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    genre VARCHAR(100),
    release_year INT,
    director VARCHAR(100),
    rating FLOAT
);

-- Ratings Table (Users rate movies)
CREATE TABLE Ratings (
    rating_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    movie_id INT,
    rating FLOAT CHECK (rating BETWEEN 0 AND 5),
    review TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (movie_id) REFERENCES Movies(movie_id) ON DELETE CASCADE
);

-- Insert Users
INSERT INTO Users (name, email, age, country) VALUES
('Alice', 'alice@example.com', 25, 'USA'),
('Bob', 'bob@example.com', 30, 'Canada'),
('Charlie', 'charlie@example.com', 28, 'UK');

-- Insert Movies
INSERT INTO Movies (title, genre, release_year, director, rating) VALUES
('Inception', 'Sci-Fi', 2010, 'Christopher Nolan', 4.8),
('The Dark Knight', 'Action', 2008, 'Christopher Nolan', 4.9),
('Interstellar', 'Sci-Fi', 2014, 'Christopher Nolan', 4.7),
('The Godfather', 'Crime', 1972, 'Francis Ford Coppola', 4.9);

-- Insert Ratings
INSERT INTO Ratings (user_id, movie_id, rating, review) VALUES
(1, 1, 5, 'Amazing concept!'),
(2, 1, 4.5, 'Great storytelling'),
(3, 2, 5, 'Best Batman movie ever!'),
(1, 3, 4.7, 'Mind-blowing!'),
(2, 4, 5, 'A classic masterpiece!');
 SHOW TABLES;
 SELECT * FROM movies;
 select * from users;
 select * from ratings;
 
 
 CREATE DATABASE service_db;

USE service_db;

CREATE TABLE service_requests (
    request_id INT AUTO_INCREMENT PRIMARY KEY,
    client_name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    status ENUM('Active', 'Pending', 'Resolved') DEFAULT 'Active',
    suggestion TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
create database service;
use service;
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('client', 'vendor') NOT NULL
);
select * from users;